"""
transformer_fhe_types.py
FHE Type Swapping: ganti euint32 → euint64, dll.
FHEVM-aware: handle TFHE.asEuintX(), casting, dan ACL patterns.
"""

import re
import random
from typing import Dict, List, Optional, Set, Tuple
from ast_parser import ContractMetadata, FHE_INT_TYPES, FHE_TYPE_HIERARCHY


# ─── Aturan swap yang valid ──────────────────────────────────────────────────

# Hanya allow upcasting (aman dari overflow)
# Format: source_type → [candidate_target_types]
SAFE_UPCAST_MAP: Dict[str, List[str]] = {
    "euint8":  ["euint16", "euint32", "euint64"],
    "euint16": ["euint32", "euint64"],
    "euint32": ["euint64"],
    "euint64": ["euint128"],
    # euint128 dan euint256 tidak di-upcast (tidak ada yang lebih besar / sparse support)
}

# Downcast lebih berisiko, hanya allow satu level turun
SAFE_DOWNCAST_MAP: Dict[str, List[str]] = {
    "euint16":  ["euint8"],    # risky, hanya kalau nilai kecil
    "euint32":  ["euint16"],
    "euint64":  ["euint32"],
    "euint128": ["euint64"],
}


def _get_fhe_int_types_in_source(source: str) -> Set[str]:
    """Detect tipe FHE integer yang dipakai di source."""
    found = set()
    for t in FHE_INT_TYPES:
        if re.search(r'\b' + re.escape(t) + r'\b', source):
            found.add(t)
    return found


def _get_swap_candidates(source: str, allow_downcast: bool = False) -> Dict[str, str]:
    """
    Return mapping: {old_type: new_type} untuk tipe yang ada di source.
    Hanya pilih SATU pasangan swap per kontrak untuk menjaga konsistensi.
    """
    present_types = _get_fhe_int_types_in_source(source)
    
    candidates: List[Tuple[str, str]] = []
    
    for old_type in present_types:
        # Upcast options
        if old_type in SAFE_UPCAST_MAP:
            for new_type in SAFE_UPCAST_MAP[old_type]:
                candidates.append((old_type, new_type))
        
        # Downcast options (lebih berisiko)
        if allow_downcast and old_type in SAFE_DOWNCAST_MAP:
            for new_type in SAFE_DOWNCAST_MAP[old_type]:
                candidates.append((old_type, new_type))
    
    return candidates


def _build_type_swap_map(old_type: str, new_type: str) -> Dict[str, str]:
    """
    Build complete replacement map untuk semua pattern yang perlu diganti
    ketika swap dari old_type ke new_type.
    
    Contoh swap euint32 → euint64:
    - euint32           → euint64
    - TFHE.asEuint32(   → TFHE.asEuint64(
    - euint32(          → euint64(
    """
    old_num = old_type.replace("euint", "")
    new_num = new_type.replace("euint", "")
    
    swap_map = {
        # Tipe langsung
        old_type: new_type,
        
        # TFHE casting functions
        f"TFHE.asEuint{old_num}(": f"TFHE.asEuint{new_num}(",
        
        # Explicit cast yang kadang muncul
        f"euint{old_num}(": f"euint{new_num}(",
        
        # TFHE.rand — kalau ada random generation
        f"TFHE.randEuint{old_num}()": f"TFHE.randEuint{new_num}()",
        f"TFHE.randEuint{old_num}(": f"TFHE.randEuint{new_num}(",
        
        # Gateway / decrypt patterns
        f"Gateway.requestDecryption.*euint{old_num}": f"euint{new_num}",  # handled separately
    }
    
    return swap_map


def _apply_type_swap(source: str, old_type: str, new_type: str) -> str:
    """
    Apply type swap secara atomik dan konsisten.
    Semua referensi ke old_type diganti ke new_type sekaligus.
    """
    result = source
    swap_map = _build_type_swap_map(old_type, new_type)
    
    for old_pattern, new_pattern in swap_map.items():
        # Gunakan word boundary untuk tipe, bukan untuk operator
        if old_pattern.endswith("("):
            # Function call — ganti literal string
            result = result.replace(old_pattern, new_pattern)
        else:
            # Tipe keyword — gunakan word boundary
            result = re.sub(r'\b' + re.escape(old_pattern) + r'\b', new_pattern, result)
    
    return result


def _validate_swap_safety(source: str, old_type: str, new_type: str) -> bool:
    """
    Cek apakah swap ini aman dilakukan.
    Return False kalau ada kondisi yang berisiko.
    """
    old_num = int(old_type.replace("euint", ""))
    new_num = int(new_type.replace("euint", ""))
    
    is_upcast = new_num > old_num
    
    if is_upcast:
        # Upcasting selalu safe untuk operasi aritmetik
        # Tapi cek kalau ada explicit bit-size operations
        dangerous_patterns = [
            r'TFHE\.shr\b', r'TFHE\.shl\b',  # shift operations might be bit-width dependent
            r'TFHE\.rotl\b', r'TFHE\.rotr\b',
        ]
        for pat in dangerous_patterns:
            if re.search(pat, source):
                # Ada operasi bit-shift, lebih berhati-hati
                # Masih allow tapi log warning
                pass
        return True
    
    else:
        # Downcast — lebih berisiko
        # Cek apakah ada literal yang exceed new type range
        new_max = (2 ** new_num) - 1
        
        # Cari literal numerik yang dipakai sebagai FHE operand
        literal_pattern = r'TFHE\.as' + re.escape(old_type) + r'\s*\(\s*(\d+)\s*\)'
        for m in re.finditer(literal_pattern, source):
            val = int(m.group(1))
            if val > new_max:
                return False  # literal terlalu besar untuk tipe baru
        
        return True


def apply_fhe_type_swap(
    meta: ContractMetadata,
    strategy: str = "upcast_only",
    seed: Optional[int] = None,
    swap_pair: Optional[Tuple[str, str]] = None,
) -> Optional[str]:
    """
    Apply FHE type swapping ke source code.
    
    strategy:
        "upcast_only"  — hanya upcast (paling safe)
        "any_safe"     — upcast + downcast yang terbukti safe
    
    swap_pair: kalau None, auto-pilih berdasarkan seed
    
    Return None kalau tidak ada swap yang valid.
    """
    if seed is None:
        seed = hash(meta.filename + strategy) % (2**31)
    
    rng = random.Random(seed)
    source = meta.raw_source
    
    allow_downcast = (strategy == "any_safe")
    
    if swap_pair is not None:
        old_type, new_type = swap_pair
        candidates = [(old_type, new_type)]
    else:
        candidates = _get_swap_candidates(source, allow_downcast=allow_downcast)
    
    if not candidates:
        return None
    
    # Pilih satu pasangan swap
    rng.shuffle(candidates)
    
    for old_type, new_type in candidates:
        if _validate_swap_safety(source, old_type, new_type):
            result = _apply_type_swap(source, old_type, new_type)
            if result != source:
                return result
    
    return None


def get_all_swap_variants(meta: ContractMetadata) -> List[Tuple[str, str, str]]:
    """
    Generate semua variasi swap yang valid untuk satu kontrak.
    Return: list of (old_type, new_type, modified_source)
    """
    source = meta.raw_source
    variants = []
    
    candidates = _get_swap_candidates(source, allow_downcast=False)
    
    for old_type, new_type in candidates:
        if _validate_swap_safety(source, old_type, new_type):
            result = _apply_type_swap(source, old_type, new_type)
            if result != source:
                variants.append((old_type, new_type, result))
    
    return variants
