"""
transformer_expression.py
Substitusi ekspresi yang semantically equivalent, FHEVM-aware.
Hanya substitusi yang proven safe — tidak ubah hasil eksekusi.
"""

import re
import random
from typing import List, Tuple, Optional
from ast_parser import ContractMetadata


# ─── Substitusi Solidity biasa (non-FHE) ────────────────────────────────────

# Format: (pattern, replacement, description)
# Perhatikan: hanya substitusi yang 100% safe
PLAIN_SUBSTITUTIONS: List[Tuple[str, str, str]] = [
    # Comparison negation — De Morgan style
    (r'!\s*\(\s*(\w+)\s*==\s*(\w+)\s*\)',  r'(\1 != \2)',    "neg_eq_to_neq"),
    (r'!\s*\(\s*(\w+)\s*!=\s*(\w+)\s*\)',  r'(\1 == \2)',    "neg_neq_to_eq"),
    (r'!\s*\(\s*(\w+)\s*>\s*(\w+)\s*\)',   r'(\1 <= \2)',    "neg_gt_to_lte"),
    (r'!\s*\(\s*(\w+)\s*<\s*(\w+)\s*\)',   r'(\1 >= \2)',    "neg_lt_to_gte"),
    (r'!\s*\(\s*(\w+)\s*>=\s*(\w+)\s*\)',  r'(\1 < \2)',     "neg_gte_to_lt"),
    (r'!\s*\(\s*(\w+)\s*<=\s*(\w+)\s*\)',  r'(\1 > \2)',     "neg_lte_to_gt"),
    
    # Boolean literal simplification
    (r'\b(\w+)\s*==\s*true\b',   r'\1',    "eq_true_simplify"),
    (r'\b(\w+)\s*==\s*false\b',  r'!\1',   "eq_false_simplify"),
    
    # Compound assignment expansion
    (r'\b(\w+)\s*\+=\s*(\w+)\b',  r'\1 = \1 + \2',  "expand_plus_assign"),
    (r'\b(\w+)\s*-=\s*(\w+)\b',   r'\1 = \1 - \2',  "expand_minus_assign"),
    (r'\b(\w+)\s*\*=\s*(\w+)\b',  r'\1 = \1 * \2',  "expand_mul_assign"),
    
    # Increment/decrement
    (r'\b(\w+)\+\+\b',  r'\1 += 1',  "postinc_to_plusassign"),
    (r'\b(\w+)--\b',    r'\1 -= 1',  "postdec_to_minusassign"),
    (r'\+\+(\w+)\b',    r'\1 += 1',  "preinc_to_plusassign"),
    (r'--(\w+)\b',      r'\1 -= 1',  "predec_to_minusassign"),
    
    # Power of 2 multiply/divide ↔ shift (hanya untuk unsigned — Solidity uint default unsigned)
    (r'\b(\w+)\s*\*\s*2\b',   r'(\1 << 1)',  "mul2_to_shl1"),
    (r'\b(\w+)\s*\*\s*4\b',   r'(\1 << 2)',  "mul4_to_shl2"),
    (r'\b(\w+)\s*\*\s*8\b',   r'(\1 << 3)',  "mul8_to_shl3"),
    (r'\b(\w+)\s*/\s*2\b',    r'(\1 >> 1)',  "div2_to_shr1"),
    (r'\b(\w+)\s*/\s*4\b',    r'(\1 >> 2)',  "div4_to_shr2"),
    
    # Require style variants
    (r'require\s*\(\s*(\w+)\s*>\s*0\s*,',   r'require(!(\1 == 0),',  "req_gt0_to_neq0"),
    
    # Ternary ↔ if-else (hanya kalau assignment sederhana, skip karena multi-line risky)
    # Dibiarkan manual agar tidak break formatting
]


# ─── Substitusi TFHE / FHEVM ─────────────────────────────────────────────────

def _substitute_tfhe_commutative(source: str) -> Tuple[str, int]:
    """
    Swap operand untuk operasi TFHE yang commutative.
    TFHE.add(a, b) → TFHE.add(b, a)
    TFHE.eq(a, b)  → TFHE.eq(b, a)
    """
    commutative_ops = ["add", "mul", "and", "or", "xor", "eq", "ne", "min", "max"]
    count = 0
    result = source
    
    for op in commutative_ops:
        # Match TFHE.op(arg1, arg2) — arg bisa berupa identifier atau TFHE.cast(...)
        # Simplified: hanya handle identifier arguments
        pattern = rf'TFHE\.{op}\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)'
        
        def swap_args(m, op=op):
            a, b = m.group(1), m.group(2)
            if a != b:  # hanya swap kalau beda
                return f'TFHE.{op}({b}, {a})'
            return m.group(0)
        
        new_result = re.sub(pattern, swap_args, result)
        if new_result != result:
            count += result.count(f'TFHE.{op}(') 
        result = new_result
    
    return result, count


def _substitute_tfhe_comparison_flip(source: str) -> Tuple[str, int]:
    """
    Flip comparison operator: TFHE.gt(a, b) → TFHE.lt(b, a)
    Ini semantically equivalent: a > b sama dengan b < a
    """
    flip_pairs = [
        ("gt", "lt"),
        ("lt", "gt"), 
        ("ge", "le"),
        ("le", "ge"),
    ]
    count = 0
    result = source
    
    for op1, op2 in flip_pairs:
        pattern = rf'TFHE\.{op1}\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)'
        
        def flip(m, op2=op2):
            a, b = m.group(1), m.group(2)
            return f'TFHE.{op2}({b}, {a})'
        
        new_result = re.sub(pattern, flip, result)
        if new_result != result:
            count += 1
        result = new_result
        # Hanya apply satu flip per pass untuk hindari infinite loop
        break
    
    return result, count


def _substitute_tfhe_select_to_cmux(source: str) -> Tuple[str, int]:
    """
    TFHE.select(cond, a, b) semantically sama dengan pattern tertentu.
    Kalau ada pola if-then-else encrypted, bisa direwrite.
    (Konservatif — hanya pada pola yang sangat jelas)
    """
    # TFHE.select(cond, ifTrue, ifFalse) — tidak ada substitusi safe yang meaningful
    # Lewati transformasi ini agar tidak merusak logika
    return source, 0


def _substitute_tfhe_not_double(source: str) -> Tuple[str, int]:
    """
    Hilangkan double negation: TFHE.not(TFHE.not(x)) → x
    """
    pattern = r'TFHE\.not\s*\(\s*TFHE\.not\s*\(\s*(\w+)\s*\)\s*\)'
    new_source = re.sub(pattern, r'\1', source)
    count = len(re.findall(pattern, source))
    return new_source, count


def _substitute_asEuint_chain(source: str) -> Tuple[str, int]:
    """
    Kalau ada TFHE.asEuintX(literal) yang bisa disederhanakan.
    Ini lebih ke cleanup, bukan substitusi.
    Lewati untuk safety.
    """
    return source, 0


# ─── Main transformer ────────────────────────────────────────────────────────

def apply_expression_substitution(
    meta: ContractMetadata,
    strategy: str = "plain",
    seed: Optional[int] = None,
    max_substitutions: int = 5,
) -> str:
    """
    Apply expression substitution ke source code.
    
    strategy:
        "plain"    — hanya substitusi Solidity biasa (paling safe)
        "fhe"      — hanya substitusi TFHE operations  
        "combined" — kedua-duanya
    
    max_substitutions: batasi jumlah substitusi agar tidak terlalu banyak berubah
    """
    if seed is None:
        seed = hash(meta.filename + strategy) % (2**31)
    
    rng = random.Random(seed)
    source = meta.raw_source
    applied_count = 0
    
    if strategy in ("plain", "combined"):
        # Shuffle substitution list untuk variasi
        subs = PLAIN_SUBSTITUTIONS.copy()
        rng.shuffle(subs)
        
        for pattern, replacement, desc in subs:
            if applied_count >= max_substitutions:
                break
            
            try:
                new_source = re.sub(pattern, replacement, source)
                if new_source != source:
                    source = new_source
                    applied_count += 1
            except re.error:
                continue
    
    if strategy in ("fhe", "combined"):
        # Apply TFHE-specific substitutions
        fhe_subs = [
            _substitute_tfhe_commutative,
            _substitute_tfhe_comparison_flip,
            _substitute_tfhe_not_double,
        ]
        rng.shuffle(fhe_subs)
        
        for sub_fn in fhe_subs:
            if applied_count >= max_substitutions:
                break
            new_source, cnt = sub_fn(source)
            if cnt > 0 and new_source != source:
                source = new_source
                applied_count += 1
    
    return source


def get_substitution_variants(
    meta: ContractMetadata,
    n_variants: int = 3
) -> List[str]:
    """
    Generate multiple variants dengan kombinasi substitusi berbeda.
    """
    variants = []
    strategies = ["plain", "fhe", "combined"]
    
    for i in range(n_variants):
        strategy = strategies[i % len(strategies)]
        seed = hash(meta.filename + str(i)) % (2**31)
        variant = apply_expression_substitution(
            meta,
            strategy=strategy,
            seed=seed,
            max_substitutions=3 + i,  # semakin banyak substitusi per variant
        )
        if variant != meta.raw_source:
            variants.append(variant)
    
    return variants
