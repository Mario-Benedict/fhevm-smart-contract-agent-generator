"""
validator.py
Compile check untuk hasil augmentasi menggunakan solc.
Filter kontrak yang gagal compile setelah transformasi.
"""

import os
import re
import json
import tempfile
import subprocess
import hashlib
from typing import Optional, Tuple, List
from dataclasses import dataclass


@dataclass
class ValidationResult:
    filepath: str
    is_valid: bool
    error_message: str = ""
    warnings: List[str] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


def _find_solc() -> Optional[str]:
    """Cari solc binary di PATH atau lokasi umum."""
    # Cek PATH
    try:
        result = subprocess.run(
            ["which", "solc"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    
    # Cek lokasi umum
    common_paths = [
        "/usr/bin/solc",
        "/usr/local/bin/solc",
        os.path.expanduser("~/.local/bin/solc"),
        "/opt/homebrew/bin/solc",
    ]
    for path in common_paths:
        if os.path.exists(path):
            return path
    
    # Cek py-solc-x
    try:
        from solcx import get_solc_version, install_solc, get_installed_solc_versions
        versions = get_installed_solc_versions()
        if versions:
            from solcx import compile_source
            return "solcx"  # marker bahwa pakai solcx
        else:
            print("[INFO] Installing solc 0.8.24 via py-solc-x...")
            install_solc("0.8.24")
            return "solcx"
    except Exception as e:
        print(f"[WARN] py-solc-x tidak tersedia: {e}")
    
    return None


def _extract_pragma_version(source: str) -> str:
    """Extract versi solidity dari pragma statement."""
    m = re.search(r'pragma\s+solidity\s+([^;]+);', source)
    if not m:
        return "0.8.24"
    
    version_str = m.group(1).strip()
    
    # Normalize: ambil versi konkret
    # "^0.8.19" → "0.8.19"
    # ">=0.8.0 <0.9.0" → "0.8.24"
    # "0.8.20" → "0.8.20"
    
    exact = re.search(r'(\d+\.\d+\.\d+)', version_str)
    if exact:
        return exact.group(1)
    
    # Ambil minor version
    minor = re.search(r'(\d+\.\d+)', version_str)
    if minor:
        parts = minor.group(1).split(".")
        return f"{parts[0]}.{parts[1]}.24"  # default patch
    
    return "0.8.24"


def validate_with_solcx(source: str, filepath: str) -> ValidationResult:
    """Validate menggunakan py-solc-x."""
    try:
        from solcx import compile_source, install_solc, get_installed_solc_versions
        
        version = _extract_pragma_version(source)
        
        # Pastikan versi terinstall
        installed = get_installed_solc_versions()
        installed_strs = [str(v) for v in installed]
        
        if not any(version in v for v in installed_strs):
            try:
                install_solc(version, show_progress=False)
            except Exception:
                # Fallback ke versi yang sudah ada
                if installed:
                    version = str(sorted(installed)[-1])
                else:
                    install_solc("0.8.24", show_progress=False)
                    version = "0.8.24"
        
        # Compile
        result = compile_source(
            source,
            output_values=["abi", "bin"],
            solc_version=version,
            allow_paths=["/"],
        )
        
        return ValidationResult(filepath=filepath, is_valid=True)
    
    except Exception as e:
        error_msg = str(e)
        # Extract error lines
        lines = error_msg.split('\n')
        meaningful = [l for l in lines if 'Error' in l or 'error' in l][:3]
        return ValidationResult(
            filepath=filepath,
            is_valid=False,
            error_message="\n".join(meaningful) if meaningful else error_msg[:200],
        )


def validate_with_solc_binary(source: str, filepath: str, solc_path: str) -> ValidationResult:
    """Validate menggunakan solc binary langsung."""
    # Tulis ke temp file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.sol', delete=False) as f:
        f.write(source)
        tmp_path = f.name
    
    try:
        result = subprocess.run(
            [solc_path, "--bin", "--abi", tmp_path],
            capture_output=True,
            text=True,
            timeout=30,
        )
        
        if result.returncode == 0:
            return ValidationResult(filepath=filepath, is_valid=True)
        else:
            # Extract error
            errors = [l for l in result.stderr.split('\n') if 'Error' in l][:3]
            return ValidationResult(
                filepath=filepath,
                is_valid=False,
                error_message="\n".join(errors) if errors else result.stderr[:200],
            )
    finally:
        os.unlink(tmp_path)


def validate_syntax_only(source: str, filepath: str) -> ValidationResult:
    """
    Validasi syntax ringan tanpa solc — sebagai fallback.
    Cek hal-hal dasar yang sering rusak setelah transformasi.
    """
    errors = []
    
    # 1. Brace balance
    open_braces = source.count('{')
    close_braces = source.count('}')
    if open_braces != close_braces:
        errors.append(f"Brace mismatch: {{ = {open_braces}, }} = {close_braces}")
    
    # 2. Paren balance
    open_parens = source.count('(')
    close_parens = source.count(')')
    if open_parens != close_parens:
        errors.append(f"Paren mismatch: ( = {open_parens}, ) = {close_parens}")
    
    # 3. Pragma harus ada
    if not re.search(r'pragma\s+solidity', source):
        errors.append("Missing pragma solidity")
    
    # 4. Contract declaration harus ada
    if not re.search(r'\bcontract\s+\w+', source):
        errors.append("Missing contract declaration")
    
    # 5. Cek FHE types tidak tercampur (euint32 dan euint64 di variable yang sama)
    # Ini heuristic — bukan error pasti
    
    # 6. Semicolon setelah statement
    # Skip — terlalu banyak false positive
    
    # 7. Cek tidak ada TFHE type yang tidak dikenal
    unknown_euint = re.findall(r'\beuint(\d+)\b', source)
    valid_euint_sizes = {"8", "16", "32", "64", "128", "256"}
    for size in unknown_euint:
        if size not in valid_euint_sizes:
            errors.append(f"Invalid FHE type: euint{size}")
    
    if errors:
        return ValidationResult(
            filepath=filepath,
            is_valid=False,
            error_message="; ".join(errors),
        )
    
    return ValidationResult(filepath=filepath, is_valid=True)


# ─── Main validator ──────────────────────────────────────────────────────────

_solc_path: Optional[str] = None
_solc_available: bool = None


def _init_solc():
    global _solc_path, _solc_available
    if _solc_available is None:
        _solc_path = _find_solc()
        _solc_available = _solc_path is not None
        if _solc_available:
            print(f"[INFO] Solc ditemukan: {_solc_path}")
        else:
            print("[WARN] Solc tidak ditemukan. Menggunakan syntax-only validation.")


def validate_contract(source: str, filepath: str = "contract.sol") -> ValidationResult:
    """
    Validate satu kontrak.
    Otomatis pilih metode validasi terbaik yang tersedia.
    """
    global _solc_path, _solc_available
    _init_solc()
    
    # Selalu lakukan syntax check dulu (cepat)
    syntax_result = validate_syntax_only(source, filepath)
    if not syntax_result.is_valid:
        return syntax_result
    
    # Full compile check kalau solc tersedia
    if _solc_available:
        if _solc_path == "solcx":
            return validate_with_solcx(source, filepath)
        else:
            return validate_with_solc_binary(source, filepath, _solc_path)
    
    # Fallback: syntax only
    return syntax_result


def validate_batch(
    contracts: List[Tuple[str, str]],  # list of (filepath, source)
    show_progress: bool = True,
) -> Tuple[List[ValidationResult], List[ValidationResult]]:
    """
    Validate batch kontrak.
    Return: (valid_results, invalid_results)
    """
    valid = []
    invalid = []
    
    total = len(contracts)
    for i, (filepath, source) in enumerate(contracts):
        if show_progress and i % 100 == 0:
            print(f"[VALIDATE] {i}/{total} ({len(valid)} valid, {len(invalid)} invalid)")
        
        result = validate_contract(source, filepath)
        if result.is_valid:
            valid.append(result)
        else:
            invalid.append(result)
    
    return valid, invalid
