# FHEVM Smart Contract Augmentation Pipeline

Pipeline augmentasi data non-LLM untuk smart contract yang menggunakan framework **fhevm (Zama)**.
Menghasilkan ~2000–3000 kontrak valid dari 1000 kontrak input.

---

## Struktur Direktori

```
fhevm_augmentation/
├── src/
│   ├── ast_parser.py           # Parser kontrak + class classifier
│   ├── transformer_rename.py   # Variable renaming (safest)
│   ├── transformer_expression.py # Expression substitution
│   ├── transformer_fhe_types.py  # FHE type swapping (euint32→euint64, dll)
│   ├── transformer_dead_code.py  # Dead code injection
│   ├── validator.py            # Compile check via solc/solcx
│   └── pipeline.py             # Main orchestrator
├── contracts_input/            # Taruh 1000 .sol files di sini
├── contracts_output/           # Hasil augmentasi (auto-dibuat)
│   ├── rename/
│   ├── expr/
│   ├── fheswap/
│   └── dead/
├── logs/                       # Log + stats JSON
├── requirements.txt
└── README.md
```

---

## Instalasi

```bash
pip install -r requirements.txt
```

Untuk validasi compile (opsional tapi recommended):
```bash
# Opsi 1: Install solc manual
sudo apt install solc  # Ubuntu/Debian

# Opsi 2: py-solc-x (auto-install, butuh internet)
pip install py-solc-x
python3 -c "from solcx import install_solc; install_solc('0.8.24')"
```

---

## Cara Pakai

### Basic (default targets: 1000 + 500 + 300 + 200 = 2000 baru)
```bash
python3 src/pipeline.py \
    --input  contracts_input/ \
    --output contracts_output/ \
    --logs   logs/
```

### Custom targets
```bash
python3 src/pipeline.py \
    --input  contracts_input/ \
    --output contracts_output/ \
    --target-rename     1000 \
    --target-expression  500 \
    --target-fhe-swap    300 \
    --target-dead-code   200
```

### Tanpa compile validation (lebih cepat, skip filter)
```bash
python3 src/pipeline.py \
    --input contracts_input/ \
    --output contracts_output/ \
    --no-validation
```

### FHE strategy: allow downcast juga
```bash
python3 src/pipeline.py \
    --input contracts_input/ \
    --output contracts_output/ \
    --fhe-strategy any_safe
```

### Oversample minority classes lebih agresif
```bash
python3 src/pipeline.py \
    --input contracts_input/ \
    --output contracts_output/ \
    --minority-factor 3.0
```

---

## Pipeline Detail

```
Input 1000 contracts
        │
        ▼
[STEP 1] AST Parsing
  - Extract FHE types, vars, ops
  - Classify contract type (voting/auction/token/...)
  - Compute complexity score
        │
        ▼
[STEP 2] Class Distribution Analysis
  - Hitung distribusi per class
  - Identify minority classes (< 30% max count)
  - Set oversample weight untuk minority
        │
        ▼
[STEP 3a] Variable Renaming        → target 1000 baru
  - Rename local vars + params fungsi
  - Tidak rename: state vars, event, public functions
  - Tidak rename: vars di TFHE.allow() calls
  - Strategy: prefix/readable/short (rotate per variant)

[STEP 3b] Expression Substitution  → target 500 baru
  - TFHE commutative swap: TFHE.add(a,b) → TFHE.add(b,a)
  - TFHE comparison flip: TFHE.gt(a,b) → TFHE.lt(b,a)
  - Double negation: TFHE.not(TFHE.not(x)) → x
  - Solidity: !=, <=, >=, compound assignment, etc.

[STEP 3c] FHE Type Swapping        → target 300 baru
  - Upcasting: euint32→euint64, euint16→euint32, dll
  - Ganti semua referensi sekaligus (atomik):
    euint32, TFHE.asEuint32(), TFHE.randEuint32()
  - Validasi safety sebelum apply

[STEP 3d] Dead Code Injection      → target 200 baru
  - Inject comment informatif
  - Inject require(true) / require(1==1)
  - Inject if(false){ revert() } dead branch
  - Hanya di dalam function body, bukan contract level
        │
        ▼
[STEP 4] Validation
  - Syntax check: brace/paren balance, pragma, FHE types
  - Compile check: via solc binary atau py-solc-x
  - Filter kontrak yang gagal
        │
        ▼
[STEP 5] Save + Stats
  - Output per subdirectory (rename/expr/fheswap/dead)
  - Stats JSON: distribusi sebelum/sesudah, count per type
```

---

## Output Stats

Setelah pipeline selesai, cek `logs/augmentation_stats.json`:

```json
{
  "input": 1000,
  "generated": 2000,
  "valid": 1850,
  "by_type": {
    "rename": 980,
    "expression": 420,
    "fhe_swap": 280,
    "dead_code": 170
  },
  "class_distribution_before": {
    "token_transfer": 450,
    "voting": 120,
    "auction": 80,
    ...
  }
}
```

---

## Catatan Penting untuk FHEVM

1. **Type swap hanya upcast** (default): euint32→euint64 aman, kebalikannya tidak.
   Gunakan `--fhe-strategy any_safe` untuk allow downcast (hati-hati).

2. **Tidak menyentuh**: `ebool`, `eaddress`, `einput`, `Gateway.*`, `FHEVMConfig`

3. **TFHE.allow() dilindungi**: variabel yang dipakai di `TFHE.allow()` tidak di-rename.

4. **Semua substitusi atomic**: type swap ganti semua referensi sekaligus
   (`euint32` + `TFHE.asEuint32` + `TFHE.randEuint32`) supaya tidak ada type mismatch.

---

## Troubleshooting

**Expression substitution menghasilkan 0 kontrak?**
→ Normal kalau kontrak tidak punya pola yang cocok (misal tidak ada TFHE.add commutative).
  Pipeline tetap lanjut dengan teknik lain.

**FHE swap menghasilkan sedikit?**
→ Cek apakah kontrak input punya tipe yang bisa di-upcast.
  euint64 tidak bisa di-upcast lebih jauh tanpa `--fhe-strategy any_safe`.

**Solc tidak tersedia?**
→ Pipeline otomatis fallback ke syntax-only validation (lebih permissive).
  Install solc untuk validasi penuh.

**Hasil terlalu sedikit?**
→ Naikkan `--minority-factor` atau kurangi `--target-*` sesuai jumlah kontrak input.
